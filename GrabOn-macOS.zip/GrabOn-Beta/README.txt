GrabOn — Beta installation

Requires macOS 26 or later. Supports Apple silicon and Intel Macs.
This beta has not been notarized by Apple. macOS cannot verify the developer
or confirm that this download is free of malware. Only proceed if you trust
the source of your download.

INSTALL
1. Unzip the download.
2. Drag GrabOn.app into your Applications folder.
3. Open GrabOn from Applications.
4. Look for GrabOn's icon in the menu bar. Press Command-Option-G to show
   the floating shelf. GrabOn does not appear in the Dock.

IF macOS BLOCKS GRABON
If the message says Apple could not verify GrabOn or the developer:
1. Click Done to dismiss the message, keeping the app.
2. Open Apple menu > System Settings > Privacy & Security.
3. Scroll to the Security section. Find the notice about GrabOn and click
   Open Anyway. You may need to attempt opening the app again for it to appear.
4. Authenticate if asked, then confirm Open to grant an exception for GrabOn.

This is a per-app exception. Do not disable Gatekeeper or run Terminal
commands to remove your Mac's security protections. If a message says the
app contains malware or will damage your computer, do not override it.
On a managed work/school Mac, your administrator may restrict this option.

Apple's instructions:
https://support.apple.com/guide/mac-help/mh40616/mac

AFTER OPENING
GrabOn collects newly copied text by default. Change this in Settings > General.
Open at login is enabled by default; macOS may require approval in Login Items.
For updates, quit GrabOn before replacing the app in Applications.

Beta limitations: Apple notarization and full cross-app validation remain
outstanding. Report issues at https://github.com/codenay/GrabOn/issues
